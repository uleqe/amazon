

import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource, UICollectionViewDelegate {

    @IBOutlet weak var collectionView: UICollectionView!
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var segmentControlButton: UISegmentedControl!
    
    var arr : [Item] = []
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.setNavigationBarHidden(false, animated: false)
        testDataConfigure()
    }
    
    func testDataConfigure(){
        arr.append(Item(imageId: 15, title: "Sapiens", description: "100,000 years ago, at least six human species inhabited the earth. Today there is just one. Us. Homo sapiens. How did our species succeed in the battle for dominance? Why did our foraging ancestors come together to create cities and kingdoms? How did we come to believe in gods, nations and human rights; to trust money, books and laws; and to be ens...", price: "7300 kzt"))
        arr.append(Item(imageId: 2, title: "Steve Jobs", description: "From the author of the bestselling biographies of Benjamin Franklin and Albert Einstein, this is the exclusive, New York Times bestselling biography of Apple co-founder Steve Jobs.Based on more than forty interviews with Jobs conducted over two years—as well as interviews with more than a hundred family members, friends, adversaries, competitors, a...", price: "5500 kzt"))
        arr.append(Item(imageId: 3, title: "Book of words", description: "Every kazakh must read", price: "3450 kzt"))
        arr.append(Item(imageId: 4, title: "Shoe Dog", description: "In this instant and tenacious New York Times bestseller, Nike founder and board chairman Phil Knight “offers a rare and revealing look at the notoriously media-shy man behind the swoosh” (Booklist, starred review), opening up about his company’s early days as an intrepid start-up and its evolution into one of the world’s most iconic, game-changing,...", price: "7800 kzt"))
        arr.append(Item(imageId: 6, title: "Educated", description: "Tara Westover was 17 the first time she set foot in a classroom. Born to survivalists in the mountains of Idaho, she prepared for the end of the world by stockpiling home-canned peaches and sleeping with her  In the summer she stewed herbs for her mother, a midwife and healer, and in the winter she salvaged in her father's .", price: "2600 kzt"))
        arr.append(Item(imageId: 7, title: "Principles", description: "Ray Dalio, one of the world’s most successful investors and entrepreneurs, shares the unconventional principles that he’s developed, refined, and used over the past forty years to create unique results in both life and business—and which any person or organization can adopt to help achieve their goals.In 1975, Ray Dalio founded an ", price: "2700 kzt"))
        arr.append(Item(imageId: 8, title: "Man's Search for Meaning", description: "Psychiatrist Viktor Frankl's memoir has riveted generations of readers with its descriptions of life in Nazi death camps and its lessons for spiritual survival. Based on his own experience and the stories of his patients, Frankl argues that we cannot avoid suffering but we can choose how to cope with it, find meaning in it, and move forward with re...", price: "8540 kzt"))
        arr.append(Item(imageId: 9, title: "Dune", description: "A deluxe hardcover edition of Frank Herbert's epic masterpiece--a triumph of the imagination and one of the bestselling science fiction novels of all time. This deluxe hardcover edition of Dune includes: - An iconic new cover- Stained edges and fully illustrated endpapers- A beautifully designed poster on the interior of the jacket- A redesigned ", price: "2850 kzt"))
        arr.append(Item(imageId: 10, title: "The Alchemist", description: "Paulo Coelho's enchanting novel has inspired a devoted following around the world. This story, dazzling in its powerful simplicity and inspiring wisdom, is about an Andalusian shepherd boy named Santiago who travels from his homeland in Spain to the Egyptian desert in search of a treasure buried in the Pyramids. What starts out as a journey to find...", price: "2580 kzt"))
        arr.append(Item(imageId: 11, title: "Atomic Habits", description: "The instant New York Times bestseller. Over 1 million copies sold! Tiny Changes, Remarkable Results No matter your goals, Atomic Habits offers a proven framework for improving--every day. James Clear, one of the world's leading experts on habit formation, reveals practical strategies that will teach you exactly how to form good habits, break bad o", price: "2800 kzt"))
        arr.append(Item(imageId: 12, title: "Delivering Happiness", description: "Pay brand-new employees $2,000 to quit Make customer service the responsibility of the entire company-not just a department Focus on company culture as the #1 priority Apply research from the science of happiness to running a business Help employees grow-both personally and professionally Seek to change the world Oh, and make money too ", price: "3900 kzt"))
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.configureTableView()
        tableView.isHidden = false
        collectionView.isHidden = true
        self.collectionView.dataSource = self
        self.collectionView.delegate = self
        self.collectionView.register(CollectionViewCell.nib, forCellWithReuseIdentifier: CollectionViewCell.identifider)
    }

    func configureTableView(){
        tableView.delegate = self
        tableView.dataSource = self
        tableView.register(UINib(nibName: "TableViewCell", bundle: nil), forCellReuseIdentifier: "tableView")
    }
    
    @IBAction func cartButton(_ sender: Any){
        let vc = storyboard?.instantiateViewController(identifier: "CartViewController") as! CartViewController
                        navigationController?.pushViewController(vc, animated: true)
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arr.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "tableView") as! TableViewCell
        let item = arr[indexPath.row]
        cell.addItem(imageId: item.imageId, title: item.title, description: item.description, price: item.price)
        return cell
    }
    
    @IBAction func changeLayout(_ sender: Any) {
        if !tableView.isHidden{
            tableView.isHidden = true
            collectionView.isHidden = false
        }else{
            tableView.isHidden = false
            collectionView.isHidden = true
        }
    }
    
}

extension ViewController: UICollectionViewDataSource{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return arr.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: CollectionViewCell.identifider, for: indexPath) as! CollectionViewCell
        let item = arr[indexPath.row]
        cell.addItem(imageId: item.imageId, title: item.title, description: item.description, price: item.price)
        return cell
    }
    
}

extension ViewController: UICollectionViewDelegateFlowLayout{
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: 200, height: 130)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 0
    }
}


class Item{
    var imageId = 0
    var title = ""
    var description = ""
    var price = ""

    convenience init(imageId: Int,title: String,description: String, price: String){
        self.init()
        self.imageId = imageId
        self.title = title
        self.description = description
        self.price = price
    }
}

